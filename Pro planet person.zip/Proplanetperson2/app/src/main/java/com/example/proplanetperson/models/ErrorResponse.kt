package com.example.proplanetperson.models

data class ErrorResponse(
    val success: Boolean,
    val message: String
)