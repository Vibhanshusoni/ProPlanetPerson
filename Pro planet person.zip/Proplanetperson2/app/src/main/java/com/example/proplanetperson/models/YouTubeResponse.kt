package com.example.proplanetperson.models

data class YouTubeResponse(
    val items: List<VideoItem>
)

