package com.example.proplanetperson.models

data class Item(
    val name: String,
    val price: Double
    // Add other relevant properties for your Buy/Sell items
)